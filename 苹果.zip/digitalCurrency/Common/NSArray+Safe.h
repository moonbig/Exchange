//
//  NSArray+Safe.h
//  NSArrayTest
//
//  Created by 蓝布鲁 on 2017/11/28.
//  Copyright © 2017年 蓝布鲁. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Safe)

@end
