//
//  bannerModel.m
//  digitalCurrency
//
//  Created by sunliang on 2018/3/6.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "bannerModel.h"

@implementation bannerModel

@end
