//
//  TradeNumModel.m
//  digitalCurrency
//
//  Created by sunliang on 2018/6/1.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "TradeNumModel.h"

@implementation TradeNumModel

@end
