//
//  SelectCoinTypeTableViewCell.m
//  digitalCurrency
//
//  Created by iDog on 2018/2/9.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "SelectCoinTypeTableViewCell.h"

@implementation SelectCoinTypeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
