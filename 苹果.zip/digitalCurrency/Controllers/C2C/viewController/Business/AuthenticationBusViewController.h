//
//  AuthenticationBusViewController.h
//  digitalCurrency
//
//  Created by startlink on 2018/8/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthenticationBusViewController : UIViewController

@end
