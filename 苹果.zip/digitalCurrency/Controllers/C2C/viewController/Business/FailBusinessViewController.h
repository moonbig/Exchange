//
//  FailBusinessViewController.h
//  digitalCurrency
//
//  Created by startlink on 2018/8/13.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FailBusinessViewController : UIViewController
@property (nonatomic,copy)NSString *Reasonstring;
@end
