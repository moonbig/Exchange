//
//  BusscoinModel.m
//  digitalCurrency
//
//  Created by startlink on 2018/8/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BusscoinModel.h"

@implementation BusscoinModel

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID" : @"id"};
}
@end

@implementation MyCoin

@end

