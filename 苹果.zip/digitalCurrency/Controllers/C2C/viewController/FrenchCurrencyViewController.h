//
//  FrenchCurrencyViewController.h
//  digitalCurrency
//
//  Created by chu on 2018/8/2.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BaseViewController.h"

@interface FrenchCurrencyViewController : BaseViewController

@end
