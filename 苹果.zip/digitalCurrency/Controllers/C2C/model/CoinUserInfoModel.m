//
//  CoinUserInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/2/24.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "CoinUserInfoModel.h"

@implementation CoinUserInfoModel

@end
