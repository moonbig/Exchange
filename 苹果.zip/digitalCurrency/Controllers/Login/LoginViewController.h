//
//  LoginViewController.h
//  digitalCurrency
//
//  Created by sunliang on 2018/1/29.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property(nonatomic,assign)int enterType;
@property (nonatomic, assign) BOOL pushOrPresent;
@end
