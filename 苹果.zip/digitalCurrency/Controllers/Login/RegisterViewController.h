//
//  RegisterViewController.h
//  digitalCurrency
//
//  Created by sunliang on 2018/1/29.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BaseViewController.h"

@interface RegisterViewController : BaseViewController

@end
