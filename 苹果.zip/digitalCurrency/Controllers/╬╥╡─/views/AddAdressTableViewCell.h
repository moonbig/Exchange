//
//  AddAdressTableViewCell.h
//  digitalCurrency
//
//  Created by iDog on 2018/3/8.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddAdressTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *addAdress;
@property (weak, nonatomic) IBOutlet UILabel *remark;

@end
