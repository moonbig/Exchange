//
//  ChargeMoneyViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/2/7.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChargeMoneyViewController : BaseViewController
@property(nonatomic,copy)NSString *unit;
@property(nonatomic,copy)NSString *address;
@end
