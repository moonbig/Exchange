//
//  TransactionDetailsViewController.h
//  digitalCurrency
//
//  Created by chu on 2018/7/4.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BaseViewController.h"

@interface TransactionDetailsViewController : BaseViewController

@property (nonatomic, copy) NSString *orderId;

@end
