//
//  IntegralRecordViewController.h
//  digitalCurrency
//
//  Created by chu on 2019/4/28.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface IntegralRecordViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
