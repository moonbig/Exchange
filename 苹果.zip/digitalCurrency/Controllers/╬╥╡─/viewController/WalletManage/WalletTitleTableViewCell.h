//
//  WalletTitleTableViewCell.h
//  digitalCurrency
//
//  Created by startlink on 2018/7/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WalletTitleTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titlelabel;

@end
