//
//  CandyBoxModel.m
//  digitalCurrency
//
//  Created by chu on 2019/4/29.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import "CandyBoxModel.h"

@implementation CandyBoxModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
