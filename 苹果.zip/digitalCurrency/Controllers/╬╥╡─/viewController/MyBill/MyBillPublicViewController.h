//
//  MyBillPublicViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/1/31.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBillPublicViewController : UIViewController
@property(nonatomic,copy)NSString * billStatus;
@property(nonatomic,copy)NSString * payStatus;
@property(nonatomic,assign)NSInteger index;
@end
