//
//  MyEntrustDetailViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/4/11.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyEntrustInfoModel.h"

@interface MyEntrustDetailViewController : BaseViewController
@property(nonatomic,strong)MyEntrustInfoModel *model;

@end
