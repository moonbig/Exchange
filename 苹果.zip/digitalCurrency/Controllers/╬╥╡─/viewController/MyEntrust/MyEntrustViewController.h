//
//  MyEntrustViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/4/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyEntrustViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UIView *backView;

@end
