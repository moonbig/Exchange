//
//  ChangePhoneDetailViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/3/19.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePhoneDetailViewController : BaseViewController
@property(nonatomic,copy)NSString *phoneNum;
@end
