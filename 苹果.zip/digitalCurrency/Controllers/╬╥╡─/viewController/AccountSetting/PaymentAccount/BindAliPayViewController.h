//
//  BindAliPayViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/5/2.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PayAccountInfoModel.h"
@interface BindAliPayViewController : BaseViewController
@property(nonatomic,strong)PayAccountInfoModel *model;
@end
