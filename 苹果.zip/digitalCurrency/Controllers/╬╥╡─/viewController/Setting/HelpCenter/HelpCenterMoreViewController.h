//
//  HelpCenterMoreViewController.h
//  digitalCurrency
//
//  Created by chu on 2018/8/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BaseViewController.h"

@interface HelpCenterMoreViewController : BaseViewController

@property (nonatomic, strong) NSNumber *cate;

@end
