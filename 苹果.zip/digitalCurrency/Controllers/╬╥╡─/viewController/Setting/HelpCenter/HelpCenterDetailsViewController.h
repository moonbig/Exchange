//
//  HelpCenterDetailsViewController.h
//  digitalCurrency
//
//  Created by chu on 2018/8/10.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "BaseViewController.h"
#import "HelpCenterModel.h"
@interface HelpCenterDetailsViewController : BaseViewController
@property (nonatomic, strong) HelpCenterContentModel *contentModel;
@end
