//
//  AboutUsTableViewCell.m
//  digitalCurrency
//
//  Created by chu on 2018/8/13.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "AboutUsTableViewCell.h"

@implementation AboutUsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
