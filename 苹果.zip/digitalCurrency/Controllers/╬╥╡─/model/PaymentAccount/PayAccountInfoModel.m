//
//  PayAccountInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/5/2.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "PayAccountInfoModel.h"

@implementation PayAccountInfoModel

@end

@implementation PayAccountAlipayModel

@end
@implementation PayAccountBankInfoModel

@end
@implementation PayAccountWechatPayModel

@end

