//
//  SelectBankNameModel.h
//  digitalCurrency
//
//  Created by iDog on 2018/5/2.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SelectBankNameModel : NSObject
@property(nonatomic,copy)NSString *enBankName;
@property(nonatomic,copy)NSString *zhBankName;
@end
