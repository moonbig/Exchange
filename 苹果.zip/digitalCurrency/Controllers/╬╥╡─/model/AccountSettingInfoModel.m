//
//  AccountSettingInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/2/27.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "AccountSettingInfoModel.h"

@implementation AccountSettingInfoModel
+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end
