//
//  MyBillDetailInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/4/3.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "MyBillDetailInfoModel.h"

@implementation MyBillDetailInfoModel

@end

@implementation PayInfoModel

@end
@implementation AlipayModel

@end
@implementation BankInfoModel

@end
@implementation WechatPayModel

@end
