//
//  plateModel.m
//  digitalCurrency
//
//  Created by sunliang on 2018/2/11.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "plateModel.h"

@implementation plateModel

@end
