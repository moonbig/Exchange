//
//  HistoryTransactionEntrustViewController.h
//  digitalCurrency
//
//  Created by iDog on 2018/4/25.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryTransactionEntrustViewController : BaseViewController
@property(nonatomic,copy)NSString *symbol;
@end
