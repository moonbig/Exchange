//
//  TransactionViewController.h
//  digitalCurrency
//
//  Created by chu on 2019/4/25.
//  Copyright © 2019 XinHuoKeJi. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TransactionViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
