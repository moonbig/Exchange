package top.biduo.exchange.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/3.
 */
public class FenPeiBean implements Serializable {
    //币种
    public String coin;
    //平台总手续费
    public String pingtaiZ;
    //待分配收入
    public String daishouru;

}
