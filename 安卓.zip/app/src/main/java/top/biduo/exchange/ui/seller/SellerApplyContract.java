package top.biduo.exchange.ui.seller;

import top.biduo.exchange.base.Contract;



public class SellerApplyContract {

    interface View extends Contract.BaseView<SellerApplyContract.Presenter> {



    }

    interface Presenter extends Contract.BasePresenter {


    }
}
