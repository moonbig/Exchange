package top.biduo.exchange.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/7.
 */
public class LunBoBean implements Serializable {
    public String tupian;
    public String biaoshi;
}
