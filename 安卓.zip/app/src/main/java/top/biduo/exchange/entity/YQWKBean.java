package top.biduo.exchange.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/3.
 */
public class YQWKBean implements Serializable {
    //交易时间
    public String starTime;
    //姓名
    public String nname;
    //手机号
    public String iphone;
    //订单ID
    public String dingdanID;
    //交易对
    public String jiaoyiDui;
    //方向
    public String fangxiang;
    //手续费
    public String shouxufei;
    //挖币数量（BHB）
    public String wkBHB;
    //到账时间
    public String endTime;

}
