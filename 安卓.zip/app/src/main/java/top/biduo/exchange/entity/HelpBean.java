package top.biduo.exchange.entity;

public class HelpBean {


    /**
     * id : 1
     * title : 士大夫
     * sysHelpClassification : 0
     * imgUrl :
     * createTime : 2019-04-30 11:49:55
     * status : 0
     * content : <p>史蒂芬孙的方式的方式对方是否私发士大夫私发是得发生的双方都放</p>
     * author : admin
     * sort : 0
     */
    private String isTop;
    private int id;
    private String title;
    private int sysHelpClassification;
    private String imgUrl;
    private String createTime;
    private int status;
    private String content;
    private String author;
    private int sort;

    public String getIsTop() {
        return isTop;
    }

    public void setIsTop(String isTop) {
        this.isTop = isTop;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSysHelpClassification() {
        return sysHelpClassification;
    }

    public void setSysHelpClassification(int sysHelpClassification) {
        this.sysHelpClassification = sysHelpClassification;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }
}
