package top.biduo.exchange.entity;

/**
 * Created by Administrator on 2018/5/4 0004.
 */

public class GccMatch {

    /**
     * code : 0
     * message : success
     * data : 100.0
     */

    private int code;
    private String message;
    private double data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public double getData() {
        return data;
    }

    public void setData(double data) {
        this.data = data;
    }
}
