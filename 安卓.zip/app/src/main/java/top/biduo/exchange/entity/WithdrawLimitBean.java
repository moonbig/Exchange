package top.biduo.exchange.entity;

public class WithdrawLimitBean {


    /**
     * amount : 0
     * count : 0
     */

    private String amount;
    private String count;

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
