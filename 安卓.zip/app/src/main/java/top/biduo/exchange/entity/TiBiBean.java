package top.biduo.exchange.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/3.
 */
public class TiBiBean implements Serializable {
    //币种
    public String name;
    //到账时间
    public String time;
    //充币地址
    public String dizhi;
    //充值数量
    public String number;
    //手续费
    public String shouxufei;
    //状态
    public String zhuangtai;

}
