package top.biduo.exchange.config;

public class AppConfig {
    static String SOCKET_IP="192.168.31.61";
    public static String BASE_URL = "http://"+SOCKET_IP;

    public static String C2C_URL = SOCKET_IP;
    public static String MARKET_URL = SOCKET_IP;
    public static String GROUP_URL = SOCKET_IP;
    public static String HEART_URL = SOCKET_IP;

    public static final String AUTH_APP_ID="2040846200";

}
